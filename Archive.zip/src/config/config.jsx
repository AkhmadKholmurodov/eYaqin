export const BACKEND_URL = "qudgns.site";
